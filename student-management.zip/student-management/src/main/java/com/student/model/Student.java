package com.student.model;

public class Student {
    private int id;
    private String name;
    private String email;

    // DB-la irundhu edukkinra data-ukku
    public Student(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    // Pudhu student add panna
    public Student(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
}