package com.student.main;

import com.student.dao.StudentDAO;
import com.student.model.Student;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n==================================");
            System.out.println("  STUDENT MANAGEMENT SYSTEM (CRUD)");
            System.out.println("==================================");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update Student Email");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 1) {
                System.out.print("Enter Name: ");
                String name = sc.nextLine();
                System.out.print("Enter Email: ");
                String email = sc.nextLine();
                dao.addStudent(new Student(name, email));
            } else if (choice == 2) {
                System.out.println("\n--- Student List ---");
                for (Student s : dao.getAllStudents()) {
                    System.out.println("ID: " + s.getId() + " | Name: " + s.getName() + " | Email: " + s.getEmail());
                }
            } else if (choice == 3) {
                System.out.print("Enter Student ID to Update: ");
                int id = sc.nextInt();
                sc.nextLine();
                System.out.print("Enter New Email: ");
                String newEmail = sc.nextLine();
                dao.updateStudentEmail(id, newEmail);
            } else if (choice == 4) {
                System.out.print("Enter Student ID to Delete: ");
                int id = sc.nextInt();
                dao.deleteStudent(id);
            } else if (choice == 5) {
                System.out.println("Exiting System... Bye!");
                break;
            } else {
                System.out.println("Invalid choice! Try again.");
            }
        }
        sc.close();
    }
}