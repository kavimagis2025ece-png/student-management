package com.student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBTest {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/studentmanagement";
        String user = "root";
        String password = "kavimagi2127*";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println("=== 1. DATABASE CONNECTED ===");

            // ----------------------------------------------------
            // STEP 1: INSERT DATA (Create)
            // ----------------------------------------------------
            String insertQuery = "INSERT INTO student (name, email) VALUES (?, ?)";
            PreparedStatement pstmtInsert = con.prepareStatement(insertQuery);
            pstmtInsert.setString(1, "Raja");
            pstmtInsert.setString(2, "raja@gmail.com");
            pstmtInsert.executeUpdate();
            System.out.println("\n=== 2. DATA INSERTED (Raja, raja@gmail.com) ===");

            // ----------------------------------------------------
            // STEP 2: UPDATE DATA (Update)
            // ----------------------------------------------------
            String updateQuery = "UPDATE student SET email = ? WHERE name = ?";
            PreparedStatement pstmtUpdate = con.prepareStatement(updateQuery);
            pstmtUpdate.setString(1, "raja_updated@gmail.com");
            pstmtUpdate.setString(2, "Raja");
            pstmtUpdate.executeUpdate();
            System.out.println("\n=== 3. DATA UPDATED (Raja's email changed) ===");

            // ----------------------------------------------------
            // STEP 3: READ DATA (Select & Display)
            // ----------------------------------------------------
            System.out.println("\n=== 4. FETCHING ALL STUDENTS FROM DATABASE ===");
            String selectQuery = "SELECT * FROM student";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(selectQuery);

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + 
                                   " | Name: " + rs.getString("name") + 
                                   " | Email: " + rs.getString("email"));
            }

            // ----------------------------------------------------
            // STEP 4: DELETE DATA (Delete)
            // ----------------------------------------------------
            String deleteQuery = "DELETE FROM student WHERE name = ?";
            PreparedStatement pstmtDelete = con.prepareStatement(deleteQuery);
            pstmtDelete.setString(1, "Raja");
            pstmtDelete.executeUpdate();
            System.out.println("\n=== 5. DELETED TEST USER (Raja) ===");

            con.close();
            System.out.println("\n=== ALL OPERATIONS COMPLETED SUCCESSFULLY! ===");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}