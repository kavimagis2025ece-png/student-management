package com.student.dao;

import com.student.model.Student;
import com.student.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    // 1. Add Student
    public void addStudent(Student student) {
        String sql = "INSERT INTO students (name, email) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, student.getName());
            pstmt.setString(2, student.getEmail());
            pstmt.executeUpdate();
            System.out.println("\n☑ Student Added Successfully!");
        } catch (Exception e) {
            System.out.println("\n❌ Error Adding Student!");
            e.printStackTrace();
        }
    }

    // 2. View All Students
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                Student s = new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email")
                );
                students.add(s);
            }
        } catch (Exception e) {
            System.out.println("\n❌ Error Fetching Students!");
            e.printStackTrace();
        }
        return students;
    }

    // 3. Update Student Email
    public void updateStudentEmail(int id, String newEmail) {
        String sql = "UPDATE students SET email = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newEmail);
            pstmt.setInt(2, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("\n✅ Student Email Updated Successfully!");
            } else {
                System.out.println("\n⚠️ Student ID Not Found!");
            }
        } catch (Exception e) {
            System.out.println("\n❌ Database Error!");
            e.printStackTrace();
        }
    }

    // 4. Delete Student
    public void deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("\n✅ Student Deleted Successfully!");
            } else {
                System.out.println("\n⚠️ Student ID Not Found!");
            }
        } catch (Exception e) {
            System.out.println("\n❌ Database Error!");
            e.printStackTrace();
        }
    }
}